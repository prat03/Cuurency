//
//  DropDownViewController.swift
//  CurrencyConversion
//
//  Created by V, Giriprasath (Contractor) on 06/06/23.
//

import UIKit
//import iOSDropDown

class DropDownViewController: UIViewController {

    @IBOutlet weak var DropDownView: UIView!
    
    @IBOutlet weak var DropDownButton: UIButton!
    
    @IBOutlet weak var CountryLabel: UILabel!
    
    //let myDropDown = DropDown()
    
    @IBAction func isTappedDropDownButton(_ sender: Any) {
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

}
