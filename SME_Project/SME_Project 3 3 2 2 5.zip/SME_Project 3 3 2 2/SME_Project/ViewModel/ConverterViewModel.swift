//
//  ConverterViewModel.swift
//  Coinage
//
//  Created by Leena, Jayakumar (Contractor) on 26/06/23.
//

import Foundation
import Network
class ConverterViewModel{
    
    let monitor = NWPathMonitor()
    var isConnected = false
    init() {
        monitor.pathUpdateHandler = { nwPath in
            switch nwPath.status{
            case .satisfied:
                print("connection available")
                self.isConnected = true
            case .unsatisfied:
                print("No connection")
                self.isConnected = false
            case .requiresConnection:
                print("connecting..")
                self.isConnected = false
            default:
                break
            }
        }
        monitor.start(queue: DispatchQueue(label: "myqueue"))
    }

    let conversionModel = ConversionUtility.shared
    
    func getConversion(amount: String, from: String, to: String, callback: @escaping (CountryInfo) -> Void){
        if isConnected{
            conversionModel.getConvertCurrency(amount: amount, from: from, to: to, handler: callback)
        }
        else{
            
        }
    }
    func add(amount: String, fromcount: String, toCount: String, conAmt: String, conRate: String){
        conversionModel.addData(amount: amount, fromcount: fromcount, toCount: toCount, conAmt: conAmt, conRate: conRate)
    }
    func delete(data: CurrencyConv){
        conversionModel.del(data: data)
    }
    func getAll() -> [CurrencyConv]{
        conversionModel.getAllData()
    }
    func clearAll(){
        conversionModel.clearAllData()
    }
    
}
