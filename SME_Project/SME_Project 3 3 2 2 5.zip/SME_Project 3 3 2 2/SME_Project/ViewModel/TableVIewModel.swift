//
//  TableVIewModel.swift
//  Coinage
//
//  Created by Leena, Jayakumar (Contractor) on 26/06/23.
//

import Foundation

struct TableViewModel{
    
    let tableModel = TableUtility.shared
    func country(callback: @escaping ([CountryDetails]) -> Void){
        tableModel.countries(handler: callback)
    }
    func addCodes(country: String, code: String){
        tableModel.addCountryCode(country: country, code: code)
    }
    func getDatas() -> [CountryCodes]{
        tableModel.getAllData()
    }
    
}
