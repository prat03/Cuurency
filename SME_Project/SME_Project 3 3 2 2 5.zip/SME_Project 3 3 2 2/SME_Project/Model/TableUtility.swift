//
//  CountryUtility.swift
//  SME_Project
//
//  Created by V, Giriprasath (Contractor) on 13/06/23.
//

import Foundation
import UIKit
import CoreData
struct CountryDetails: Codable{
    let supported_codes: [[String]]
}


struct TableUtility{
    let apiKey = "6de0bead0f3ec79f4dfa75df"
    let tmbUrl = "https://v6.exchangerate-api.com/"
    
    
    static var shared = TableUtility()
    let dBContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    private init(){
        
    }
    
    func countries(handler: @escaping ([CountryDetails]) -> Void){
        let upcomingUrl = "\(tmbUrl)v6/\(apiKey)/codes"
        
        if let tmbnew = URL(string: upcomingUrl){
            let session = URLSession.shared
            
            let task = session.dataTask(with: tmbnew) { countrydata, resp, error in
                if error == nil{
                    if let sCode = (resp as? HTTPURLResponse)?.statusCode{
                        switch sCode{
                        case 200...299:
                            print("Success: \(tmbnew)")
                            let countryList = parseData(cData: countrydata)
                            handler(countryList)
                            
                        default:
                            print("Failed: \(sCode)")
                        }
                    }
             }
                else{
                    print("Network error")
                    
                }
                
            }
            task.resume()
        }
        else{
            print("invalid url")
        }
        

    }
    
    func parseData(cData: Data?) -> [CountryDetails]{
        guard let countrydata = cData else{
            print("data is not available")
            return []
        }
        print("Parse data")
        do{
            let CountryResult = try JSONDecoder().decode(CountryDetails.self, from: countrydata)
            print("Got: \(CountryResult.supported_codes.count)")
          
            return [CountryResult]
        }catch{
            print("Decoding error: \(error.localizedDescription)")
        }
        return []
    }
    
    func addCountryCode(country: String, code: String){
        let data = CountryCodes(context: dBContext)
        data.countries = country
        data.code = code
        
        do{
            try dBContext.save()
            print("datas added..\(country), \(code)")
        }catch{
            print("data not added: \(error.localizedDescription)")
        }
        
    }
    func getAllData() -> [CountryCodes]{
        let dataReq = CountryCodes.fetchRequest()
        do{
            let result = try dBContext.fetch(dataReq)
           return result
        }
        catch{
            return []
        }
        
    }
}

