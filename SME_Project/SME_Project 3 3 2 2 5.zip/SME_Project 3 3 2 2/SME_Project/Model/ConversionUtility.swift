//
//  CurrencyUtility.swift
//  SME_Project
//
//  Created by Leena, Jayakumar (Contractor) on 08/06/23.
//
import UIKit
import Foundation
import CoreData

    struct CountryInfo: Codable {
        var conversion_result: Double
        var conversion_rate: Double
    }
    
    struct ConversionUtility {
        
        
        static var shared = ConversionUtility()
        let dbContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

        
        private init(){
            
        }
        
        func getConvertCurrency(amount: String, from: String, to: String, handler: @escaping (CountryInfo) -> Void){
            
            let webUrl = "https://v6.exchangerate-api.com/v6/29b79ed48bf9639c1ee3fb4c/pair/\(from)/\(to)/\(amount)"
            
            //Refernce of URL Session
            let session = URLSession.shared
            
            //create request
            if let url = URL(string: webUrl){
                
                
                //create task
                let task = session.dataTask(with: url) { convertdata, resp, err in
                    
                    if err == nil {
                        print("success: \(webUrl)")
                        if let sCode = (resp as? HTTPURLResponse)?.statusCode{
                            switch sCode {
                            case 200...299:
                                print("success \(sCode)")
                                let countryInfo = parseData(jsonResponse: convertdata)
                                handler(countryInfo!)
                                
                            default:
                                print("failed")
                            }
                            
                        }
                    }
                    else{
                        print("request failed")
                    }
                }
                task.resume()
            }
            else{
                print("invalid url")
            }
        }
        
        
        func parseData(jsonResponse: Data?) -> CountryInfo? {
            guard let jResponse = jsonResponse else{
                return nil
            }
            do{
                let countryInfo = try JSONDecoder().decode(CountryInfo.self, from: jResponse)
                print("decoding done")
                return countryInfo
            }
            catch{
                print("parsing failed: \(error.localizedDescription)")
            }
            return nil
        }

        func addData(amount: String, fromcount: String, toCount: String, conAmt: String, conRate: String){
            let data = CurrencyConv(context: dbContext)
            data.amount = amount
            data.fromCoun = fromcount
            data.toCoun = toCount
            data.cAmt = conAmt
            data.cRate = conRate
            
            do{
                try dbContext.save()
                print("datas added..\(amount)")
            }catch{
                print("data not added: \(error.localizedDescription)")
            }
            
        }
        func del(data: CurrencyConv){
            dbContext.delete(data)
            do{
                try dbContext.save()
                print("datas deleted: \(data.amount ?? "")")
            }
            catch{
                print("data not deleted: \(error.localizedDescription)")
            }
        }
        func getAllData() -> [CurrencyConv]{
            let dataReq = CurrencyConv.fetchRequest()
            do{
                let result = try dbContext.fetch(dataReq)
               return result
            }
            catch{
                return []
            }
            
        }
        func clearAllData(){
            let delete = NSBatchDeleteRequest(fetchRequest: CurrencyConv.fetchRequest())
            do{
                try dbContext.execute(delete)
               // print("datas deleted: \(data.amount ?? "")")
            }
            catch{
                print("data not deleted: \(error.localizedDescription)")

        }
    }
    }
    
    

