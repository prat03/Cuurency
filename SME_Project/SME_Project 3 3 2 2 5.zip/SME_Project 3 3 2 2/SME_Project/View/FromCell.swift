//
//  FromCell.swift
//  SME_Project
//
//  Created by Leena, Jayakumar (Contractor) on 21/06/23.
//

import UIKit

class FromCell: UITableViewCell {

   
    @IBOutlet weak var code: UILabel!
    
    
    @IBOutlet weak var country: UILabel!
    
}
