//
//  ToCell.swift
//  SME_Project
//
//  Created by Leena, Jayakumar (Contractor) on 21/06/23.
//

import UIKit

class ToCell: UITableViewCell {

   
    @IBOutlet weak var tocode: UILabel!
    
    
    @IBOutlet weak var tocountry: UILabel!
    
}
