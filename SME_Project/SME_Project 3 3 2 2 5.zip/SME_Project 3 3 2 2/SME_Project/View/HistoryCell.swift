//
//  HistoryCell.swift
//  SME_Project
//
//  Created by Leena, Jayakumar (Contractor) on 13/06/23.
//

import UIKit

class HistoryCell: UITableViewCell {

    @IBOutlet weak var frmL: UILabel!
    
    @IBOutlet weak var amtL: UILabel!
    
    
    @IBOutlet weak var conamtL: UILabel!
    
    @IBOutlet weak var toL: UILabel!
    
    
}
