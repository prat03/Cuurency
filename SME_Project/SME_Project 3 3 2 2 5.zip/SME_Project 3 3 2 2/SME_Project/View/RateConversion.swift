//
//  CurrencyRatesViewController.swift
//  SME_Project
//
//  Created by V, Giriprasath (Contractor) on 08/06/23.
//

import UIKit

struct CurrencyRates: Codable{
    let base_code: String
    let conversion_rates: [String: Double]
}

class RateConversion: UIViewController {
    
    @IBOutlet weak var currencyTF: UITextField!
    
    @IBOutlet weak var codeTF: UITextField!
    
    @IBOutlet weak var conversionRatesTV: UITableView!
    
    
    @IBOutlet weak var progressIndicator: UIActivityIndicatorView!
    
var base_code: CurrencyRates?
        
var base_rate:Double  =  1.0

override func viewDidLoad() {
    super.viewDidLoad()
        
    conversionRatesTV.dataSource = self
                
    conversionRatesTV.allowsSelection = false
    conversionRatesTV.showsVerticalScrollIndicator = false
    
    progressIndicator.isHidden = true
                
    fetchData()
        
}
    
@IBAction func convertB(_ sender: UIButton) {
    
    if let getString = currencyTF.text{
        progressIndicator.isHidden = false
        progressIndicator.startAnimating()
        if let isDouble = Double(getString){
            base_rate = isDouble
            fetchData()
            print("print data")
        }
    }
}
    
func fetchData(){
    
    let getCode = codeTF.text ?? ""
    let url = URL(string: "https://v6.exchangerate-api.com/v6/6de0bead0f3ec79f4dfa75df/latest/\(getCode)")
              
    URLSession.shared.dataTask(with: url!){ (data, response, error) in
        if error == nil{
            do{
                
                self.base_code = try JSONDecoder().decode(CurrencyRates.self, from: data!)
                
            } catch{
                    print("Parse error")
            }
            DispatchQueue.main.sync {
                self.progressIndicator.stopAnimating()
                self.progressIndicator.isHidden = true
                self.conversionRatesTV.reloadData()
            }
        }
        else{
            print("error")
        }
    }.resume()
}
      
}

extension RateConversion: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if let currencyFetched = base_code{
            return currencyFetched.conversion_rates.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        if let currencyFetched = base_code{
            cell.textLabel?.text = Array(currencyFetched.conversion_rates.keys)[indexPath.row]
            let selectedRate = base_rate *  Array(currencyFetched.conversion_rates.values)[indexPath.row]
            cell.detailTextLabel?.text = "\(selectedRate)"
            return cell
        }
        return UITableViewCell()
    }
}
